# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
data <- read.csv('mtcars (1).csv')
data
head(data)
summary(data)
# 1. Which cars have an MPG greater than 25?
q1 <- data[data$mpg > 25,]
q1
# 2. What is the average horsepower for cars with an MPG less than 20? Ans: 191.9444
q2 <- data[data$mpg < 20, ]
m = mean(q2$hp)
print(m)
# 3. How many cars have 4 cylinders, and how do their weights compare to those with 8 cylinders
cof4cyl <- sum(data$cyl == 4)
print(cof4cyl)
q34 <- data[data$cyl==4, ]
q38 <- data[data$cyl==8, ]
q34m <- mean(q34$wt)
q38m <- mean(q38$wt)
differnce = abs(q34m-q38m)
print(differnce)
