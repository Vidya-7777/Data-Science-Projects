# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
#List is always 1D, whereas dataframe it is not the same
foo <- list(matrix(data=1:4, nrow=2, ncol=2), c(T,F,T,T), "hello")
foo[3]
mydata <- data.frame(person=c("Peter", "Lois", "Meg", "Chris", "Stewie"),
age = c(42, 40, 17, 14, 1),
gender = factor(c("M", "F", "F" ,"M", "M")))
#factor is mainly for accesing catogerical data which is sometimes ordered, we have more functionality especially when plotted
mydata
#printing the data of peter
mydata[1,] #selects all the columns of the first row
#Adding new data
newrecord <- data.frame(person = "Brian", age = 7, gender = factor("M", levels=levels(mydata$gender)))
# levels=levels(mydata$gender) => this specifies that the new column is in the same level of the original data frame
newrecord
mydata <- rbind(mydata, newrecord)
mydata
# Adding columns or features
funny <- c("High", "High", "Low", "Med", "High", "Med")
# different distinct values in the feature
funny <- factor(x=funny, levels = c("Low", "Med", "High"))
funny
mydata <- cbind(mydata, funny)
mydata
# Creating a new feature
mydata$age.mon <- mydata$age*12
mydata
# Logical operators and filtering
# Extract the data of all the male
sub1 <- mydata[mydata$gender == "M", ] # Row operation
sub1
# printing all the male with the columns age, funny
sub2 <- mydata[mydata$gender == "M", c("age.mon" , "funny")] 
sub2
sub3 <- mydata[mydata$gender == "M", c(1,2)] 
sub3
# Have more than 10 years or high degree of funiness
sub4 <- mydata[mydata$age < 10 | mydata$funny == "High",]
sub4