# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
#na.omit() => omits all the na values
library(dplyr)
data("airquality")
airquality
mayzone <- airquality %>% filter(Month == 5) %>%select(Ozone)
augzone <- airquality %>% filter(Month == 8) %>%select(Ozone)
#removing the NA values
mayzone <- na.omit(mayzone)
augzone <- na.omit(augzone)
#Prforming two-sample T-test
t_test_result <- t.test(mayzone, augzone, var.equal=TRUE)# considering the variances are same => assumes that the data are normally distributed
print(t_test_result)
#continuous values => T-test
#Nominal values => have some categorical values like checking the mark between male and female data (rank, => Go for non parametric that relies on median
#when we are not sure, use wilcoxon test - non parametric rank sum
# Test if the median wind speeds differ between two months using wilcoxon rank-sum test
#Extract data for June and July
june_wind <- airquality %>% filter (Month == 6) %>% select(Wind)
july_wind <- airquality %>% filter (Month == 7) %>% select(Wind)
#Removing the null values
june_wind <- na.omit(june_wind)
july_wind <- na.omit(july_wind)
wilcoxon_result <- wilcox.test(june_wind$Wind, july_wind$Wind)
print(wilcoxon_result)
#alternate hypothesis: true locatio shift is not equal to 0
#Wilcoxon rank-sum test is the non-parametric equivalent of the t-test
#Does not use normality, uses the rank of the data
#Continuous distribution
#Objective: Explore the distribution o temperature and fit a normal distribution
#Extract the temperature data
temperature <- airquality$Temp
#Remove the NA Values
temperature <- na.omit(temperature)
#Plot histogram
hist(temperature, breaks = 10, probability =TRUE, main = "Histogram of Temperaure", xlab = "Temperature (F)")
#Fit and overlay normal distributin
temp_mean <- mean(temperature)
temp_sd <- sd(temperature)
curve(dnorm(x, mean = temp_mean, sd = temp_sd), add = TRUE, col = "blue", lwd = 2)
#add = TRUE => Overlays on the previous image
#discrete probability distribution
#Analyze the number of Observations per month
#similar to value_counts()
#Create a table of counts per month
month_counts <- table(airquality$Month)
#Display the counts
print(month_counts)
#plot bar chart
barplot(month_counts, main = "Number of Observations per Month", xlab = "Month", ylab = "Frequency", names.arg = c("May", "June", "July", "August", "September"))
#Correlation and Covariance
#Determine the strength and direction of the relationship between ozone levels and solar radiation
#Extract ozone and solar radiation data
ozone <- airquality$Ozone
#remove NA values
data_complete <- na.omit(data.frame(ozone, solar))
#Calculate Pearson correlation coefficient
cor_pearson <- cor(data_complete$ozone, data_complete$solar)
#display the correlation coefficient
print(paste("Pearson correlation coefficient: ", round(cor_pearson, 3)))
#Scatter plot with regressin line
plot(data_complete$solar, data_complete$ozone, main = "Ozone vs Solar Radiation", xlab = "solar Radiation(lang)", ylab = "Ozone (ppb)", pch = 16)
# ~ => formula sign
abline(lm(ozone ~ solar, data = data_complete), col = "red", lwd = 2)
#solar => dependent
#ozone => independent
#no order => spearman
#order => tendal
#refer plotting in bookdown
# check pics in phone regarding this on phone