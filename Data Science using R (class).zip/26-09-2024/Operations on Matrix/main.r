#
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
#
#
# [ ] vector subsetting or extraction
A <- matrix(data = c(-3, 2, 893, 0.17), nrow = 2, ncol = 2)
A
B <- matrix(data = c(-3, 2, 893, 0.17), nrow = 2, ncol = 3) #it does not throw an error, it fills the value by column as default
B
C <- matrix(data = c(-3, 2, 893, 0.17), nrow = 2, ncol = 3, byrow=TRUE) #it fills by row
C
D <- rbind(1:3, 4:6)
D
E <- cbind(1:3, 4:6)
E
# Creating inconsistency
G <- rbind(1:4, 7:9) #replicates the first value
G
H <- cbind(c(1,2,3,4), c(5,6,7,8), c(9,10,11,12))
H
print(dim(H))
#Do subseting of a particular matrix, then do diagnol seperately
H[c(3,1),2:3]
H
H[,c(-2)] #drops the second column
H[c(-2),] #drops the second row
# H[1,2] = 900
# H[4,2] = 900
# print(H)
H[c(1,4),2] <- 900
print(H)
R <- rbind(c(2,5,2), c(6,1,4))
R
# Transpose of a matrix
t(R)
#diagnol function is used to create a identity matrix
I <- diag(x=3)
I
# Performing scalar multiplication element wise
r <- 2
r*R
# the symmetry of the matrix doesn't matter here
#matrix multiplication - symmetry of the two matrix is checked and then computed
X <- rbind(1:2, 3:4)
Y <- rbind(5:6, 7:8)
X %*% Y
#inversion
Xinverse <- solve(X)
X %*% Xinverse