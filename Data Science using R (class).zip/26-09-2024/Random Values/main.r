# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
#Generating a random data
# by default it is from 0 to 1 (default seed)
random_number <- runif(1) #generates one value
print(random_number)
#Generating multiple random values
random_number1 <- runif(5) #generates 5 values
print(random_number1)
# for getting similar value we should use seeding
#for generating random values in specific range
# random_number2 <- runif(no_of_values_we_need, min=a, max=b)
# a is upper bound
# b is lower bound
random_number2 <- runif(2, min=2, max=5)
print(random_number2)
#generate a random numbers between 1 to 10 and create 3x3 matrix
#generate a random number from 1 to 6 for a die
random_die <- sample(1:6, 1)
random_die