# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
#?mean #Help function
14/6
2+3
14/6+5
14/(6+5)
3^2
2^3
sqrt(x=9)
sqrt(x=5.311)
print((10^2)+((3*60)/8)-3)
print(((5^3)*(6-2))/(61-3+4))
a = 2^(2+1)
b = 64^((-2)^(2.25-(1/4)))
c = 4
d = a-c+b
print(d)
e = (1-0.44)
f = (0.44 * e)/34
g = f^(1/2)
print(g)
log(x=243,base=3)
#2.5e12 is equivalent to 2.5 x 10^12
x <- -5
print(x)
y <- x
print(y)
vec <- c(1,2,3,4,5)
vec2 <- c(7,(8/2),9.5,x,y)
vec3 = c(vec,vec2)
print(vec2)
print(vec3)
print(3:27)
print(5.3:-44.7, step=-0.7)