# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
library(dplyr)
# The dplyr is analogus to SQL
# The dplyr package in R is a powerful tool to data manipulation, offering a range of functions to easily manipulate
# and analyze data frames. Some of it's main functions are select(), filter(), mutate(), summarize(), group_by()
data1 = read.csv("mtcars (1).csv")
print(data1)
glimpse(data1)
glimpse(mtcars)
print(summary(mtcars))
#select() => chooses the specific column
#selecting the mpg and hp columns
mtcars_selected <- mtcars %>% select(mpg, hp)
head(mtcars_selected)
#filter() => filtering the rows based on some conditions
#filter the cars with mpg greater than 20 and hp greater than 100
mtcars_filtered <- mtcars %>% filter(mpg > 20, hp >100)
head(mtcars_filtered)
#mutate() => This is similar to crud qoperation in SQL
#It helps to create (add new columns) or modify the (existing)columns
#Add a new column called "hp_per_cyl" which is horsepower per cylinder
mtcars_mutated <- mtcars %>% mutate(hp_per_cyl = hp/cyl)
head(mtcars_mutated)
#summarize() => It summarizes ir aggregates the data, It is used to calculate the summary statistics like mean, etc
mtcars_summary <- mtcars %>% summarize(avg_mpg = mean(mpg), avg_hp = mean(hp))
mtcars_summary
#Group_by() => It groups the data by one or more variables before applying summarizing operations.
#This is useful for calculating statistics of each data
#group by the number of cylinders and calculate the average mpg and hp for each group
mtcars_grouped_summary <- mtcars %>% group_by(cyl) %>% summarize(avg_mpg = mean(mpg), avg_hp = mean(hp))
mtcars_grouped_summary
#Find the average horsepower of cylinder group for cars with more than 100 horsepower, but only return the mpg, hp, and cyl columns
mtcars_grouped_summary1 <- mtcars %>% filter(hp>100) %>% group_by(cyl) %>% summarize(avg_hp = mean(hp)) %>% select(cyl, avg_hp)
mtcars_grouped_summary1
#check photos in phone for more information and add here