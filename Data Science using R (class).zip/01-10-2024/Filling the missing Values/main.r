# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
data <- data.frame(Feature1 = c(1, 2, NA, 4, NaN, 6, 7), Feature2 = c("A", NA, "C", "D", "E", "F", NA),
                   Feature3 = c(10, 20, NA, 40, 50, NaN, 70), Feature4 =c(TRUE, FALSE, NA, TRUE, FALSE, TRUE, NA),
                   Feature5 = c(NA, NaN, 30, 40, 50, 60, 70))
data
summary(data)
#we can also find using is.na
is.na(data)
print(sum(is.na(data$Feature1))) #will consider nan as well
print(sum(is.nan(data$Feature1))) #will consider only nan #it works for a particular function, but not for the whole data set
#Replace NaN with 0
df1 <- data
df1$Feature1[is.na(df1$Feature1)] <- 0
df1
# df1$Feature1[is.na(df1$Feature1)] <- 0
# df1
#Mean imputation
print(mean(df1$Feature3, na.rm=TRUE)) #computing the mean excluding the NA values based on the particular Feature
df1$Feature3[is.na(df1$Feature3)] <- mean(df1$Feature3, na.rm = TRUE)
df1
#Median Imputation
print(median(df1$Feature5, na.rm = TRUE))
df1$Feature5[is.na(df1$Feature5)] <- median(df1$Feature5, na.rm = TRUE)
df1