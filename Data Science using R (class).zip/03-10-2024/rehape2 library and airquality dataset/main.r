# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
library(reshape2)
data <- data.frame(
  Name = c("John", "Mary", "Peter"),
  Math = c(90, 85, 88), 
  Science = c(92, 88, 89), 
  English = c(89, 92, 94)
)
melted_data <- melt(data, id.var = "Name", variable.name = "Variable", value.name="Value")
melted_data
#Inverse of melt function
#Casting the melted data back into wide format
casted_data <- dcast(melted_data, Name ~ Variable, value.var = "Value")
casted_data
data("airquality")
#trying to convert into the long format, retaining the month and the day (include them in id.vars)
melted_data1 <- melt(airquality, id.vars = c("Month", "Day"), variable.name = "Measurement", value.name = "Value")
head(melted_data1)
dcast_data <- dcast(melted_data1, Month+Day~Measurement, value.var="Value")
head(dcast_data)
#Objective: Test if the mean ozone levels differ between two monthsusing a two-sample t-test
#can use normal subsetting operation or we can use dplyr
#Perform t_tesr