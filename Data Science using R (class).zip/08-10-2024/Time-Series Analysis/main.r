# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
#Time series analysis with the Airpassengers Dataset
# Load and Plot the data
data("AirPassengers")
head(AirPassengers)
#basic plot of the time series
plot(AirPassengers, main="AirPassengers Data", xlab="Year", ylab="Passengers", col="blue", lwd=2)
#peaks occuring in regular intervals tells about seasonality
#decompse the time series
decompose_data <- decompose(AirPassengers)
plot(decompose_data)
