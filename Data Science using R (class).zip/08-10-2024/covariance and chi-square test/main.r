# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
#Correlation and Covariance
#closer to 1 => strong positive correlation
#closer to -1 => strong negative correlation
#Coorealtion - 1st order calculation
#Covariance - 2nd oder calculation
#To find covariance between Wind and Temperature:




#Covariance : measure of how two variables change together
#Positive covariance indicates that variables increae together, negative correlation indicates one incerase while the other decreases.
#Contigency Table:
#examine the realtionship between wind speed categories and ozone level categories using a contigency table
#we are checking if two varibles are independent by categorizing
#Checking wind speed categories: low, medium, high
airquality$WindCat <- cut(airquality$Wind, breaks = quantile(airquality$Wind, probs = seq(0, 1, 0.3), na.rm = TRUE), labels = c("low", "medium", "high"), include.lowest = TRUE)
airquality$WindCat
#Create level categories categories: low, medium, high
airquality$OzoneCat <- cut(airquality$Ozone, breaks = quantile(airquality$Ozone, probs = seq(0, 1, 0.3), na.rm = TRUE), labels = c("low", "medium", "high"), include.lowest = TRUE)
airquality$OzoneCat
#na.rm => drops the na values (rm => remove)
#0.33 because we are dividing it into 3 (1/3=0.33)
#Chi-Square test is for categorical variable analysis
#Creating a contigency table and performing Chi-Square Test:
#Remove rows with NA in categorized variables
data_categorized <- na.omit(airquality[, c("WindCat", "OzoneCat")])
#Create contigency table
contigency_table <- table(data_categorized$WindCat, data_categorized$OzoneCat)
#Display the table
print(contigency_table)
#Perform Chi-Square
chi_squared_test <- chisq.test(contigency_table)
#Display test results
print(chi_squared_test)
#Contigency table: Displays the frequency distribution of variables
#Chi-square test: Test the independence of two categorical variables
#Null hypothesis (H0) : No association between variables
#Alternative Hypothesis (H1) : There is an association
#Conclusion: Check in phone pic
