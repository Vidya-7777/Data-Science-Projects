# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
airquality$WindCat <- cut(airquality$Wind, breaks = quantile(airquality$Wind, probs = seq(0, 1, 0.3), na.rm = TRUE), labels = c("low", "medium", "high"), include.lowest = TRUE)
airquality$WindCat
#Create level categories categories: low, medium, high
airquality$OzoneCat <- cut(airquality$Ozone, breaks = quantile(airquality$Ozone, probs = seq(0, 1, 0.3), na.rm = TRUE), labels = c("low", "medium", "high"), include.lowest = TRUE)
airquality$OzoneCat
data_categorized <- na.omit(airquality[, c("WindCat", "OzoneCat")])
#Create contigency table
contigency_table <- table(data_categorized$WindCat, data_categorized$OzoneCat)
#Display the table
print(contigency_table)
#Perform Chi-Square
chi_squared_test <- chisq.test(contigency_table)
#Display test results
print(chi_squared_test)