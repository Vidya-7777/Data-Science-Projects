# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 
foo <- 5.3
bar <- foo:(-47+1.5)
bar
#Sequence
seq(from=3, to=27, by=3)
seq(from=3, to=27, length.out=40)
#Repition
rep(x=1, times=4)
rep(x=c(3, 62, 8.3), times=3)
rep(x=c(3, 62, 8.3), times=3, each=2)
#Sorting
sort(x=c(2.5, -1, -10, 3.44), decreasing = FALSE) #False => ascending
#sorting the 8 elements in descending order between 4.3 to 5.5
sort(seq(from=4.3, to=5.5, length.out=8), decreasing = TRUE)
#Create and store a sequence of values from 5 to -11 that progress in step of 0.3
a = seq(from=5, to=-11, by=-0.3)
print(a)
#Overwrite the previous object from the above using the same sequence with the order reversed
b = sort(a, decreasing = FALSE)
print(b)
#Repeat the vector c(-1, 3, -5, 7, 9) twice, with each element repeated 10 times, and store the result. Display the result sorted from largest to smallest
c = rep(x=c(-1,3,-5,7,9), times=2, each=10)
print(c)
sort(c, decreasing = TRUE)
#Subsetting 
d = c(-1,3,-5,7,9)
d[-1] #removes 1st element
d[1] #prints the element at that particular location
print(d)
length(x=d)
#dropping multiple values
# method 1 using the c operator
remove <- c(-1,3)
setdiff(d, remove)
#Excercise 2.4
aa = seq(from=3, to=6, length.out=5)
bb = rep(x=c(2, -5.1, -33), times=2)
cc = ((7/42)+2)
f = c(aa, bb, cc)
print(f)
l = length(x=f)
print(l)
#b
fe = c(f[1])
le = c(f[l])
b_object = c(fe, le)
print(b_object)
#c
rfe = c(f[-1])
rle = c(f[-l])
c_object = c(rfe, rle)
print(c_object)
#d
d_object = c(fe, c_object, le)
print(d_object)
#e
oa = sort(a, decreasing = FALSE)
a = oa
print(a)