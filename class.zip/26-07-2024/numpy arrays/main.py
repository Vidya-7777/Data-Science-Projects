'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import numpy as np
arr1 = np.array([1,2,3,4,5]) #creating a 1D array
print(arr1)
arr2 = np.array([[1,2,3], [4,5,6]]) #creating a 2D array
print(arr2)
zeros = np.zeros((3,3)) #creating an array with zeros
print(zeros)
ones = np.ones((2,4)) #creating an array with ones
print(ones)
#creating an array with a range of values
range_arr = np.arange(0,10,2) #from 0 to 10 with step 2
print(range_arr)