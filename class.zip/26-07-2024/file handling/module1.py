def greet():
    print("Pinky greets namita!")
    