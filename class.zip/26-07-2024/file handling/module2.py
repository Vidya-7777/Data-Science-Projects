def farewell():
    print("Namita farewells bus as he is boring and uncle material")