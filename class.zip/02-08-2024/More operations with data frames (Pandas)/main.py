'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Using np.Nan and None => No value in that particular location
import pandas as pd
import numpy as np
data = {
    'Employee ID': [1,2,3,4,5],
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva'],
    'Salary': [45000, 54000, np.NaN, 63000, None]
}
df = pd.DataFrame(data)
print(df[['Name', 'Salary']])
#Dropping rows with missing values
'''df.dropna(inplace=True)
print(df)'''
#Filling the missing values with a specific values
df.fillna(value={'Salary': 50000}, inplace = True)
print(df)
#adding new columns
df['Bonus'] = 5000
print(df)
#Adding a new column based on existing columns
df['Total Compensation'] = df['Salary'] + df['Bonus']
print(df)
#Filtering Data
#Performing data manipulation for a specific row
#Filtering the rows where the salary is greater thamn 60000
high_salary_df = df[df['Salary'] > 60000]
print(high_salary_df)
#Filtering the rows where the name is Eva
name_df = df[df['Name'] == 'Eva']
print(name_df)
