'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Handling missing values and data manipulation
import numpy as np
import pandas as pd
#Create a sample DataFrame with missing values
data = {'Name':['Alice', 'Bob', 'Charlie', 'David', 'Eve'], 'Age':[25,np.nan,30,np.nan,35], 'Score':[85,92,np.nan,78,'']}
df = pd.DataFrame(data)
#Printing the data frame with Missing values
print(df)
#Missing value count
print(df.isna().sum())
#Replacing a empty space with Null
#fill blank string '' with np.nan in the Score Column
#or this can also be used: 
#df['Score'] = df['Score'].replace('',np.nan)
df = df.replace('',np.nan) #df.replace(old value, replaced value)
print(df.isna().sum())
print(df)
#replacing the null values with the mean
m = df['Score'].mean()
df = df['Score'].replace(np.nan,m)
print(df)
#mean imputation:
#fillna is restricted only for the numerical columns
df_median = df.fillna(df.median())
print(df_mean)
#similarly we can do for median imputation
