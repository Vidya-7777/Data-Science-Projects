'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import pandas as pd
df = pd.read_csv("nobel.csv")
#when was the first nobel price is given?
#no of people from India
i = df[df['birth_country']=='India']
print(i.count())
#Extraction
#Extracting all people from India
c = df[df['birth_country']=='India']['full_name']
print(c)
cc = df[df['birth_country']=='India']['full_name'].count()
print(cc)
#Get the starting and the ending year
ending_year = df['year'].max()
print(ending_year)
starting_year = df['year'].min()
print(starting_year)
#Find all the columns with Null values or find the column count with nan values
#isna()
#isnull()
n = df.isnull().sum()
print(n)
#how many nobel prices are given upto 2016
nn = df[df['year']<2016]['full_name']
print(nn.count())
#how many of them won more than once
dfw = df['full_name'].value_counts()
print(dfw)
win = dfw[dfw > 1].count()
print(win)
# winners_more_than_once = df['full_name'].value_counts()
# more_than_once = winners_more_than_once[winners_more_than_once > 1]
# print(more_than_once)
# print(more_than_once.count())