'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
data = {
    'Campaign' : ['Campaign1', 'Campaign2', 'Campaign3', 'Campaign4'],
    'Impressions' : [1000, 2000, 3000, 4000],
    'Clicks' : [50, 100, 150, 200], 
    'Conversions' : [10, 20, 30, 40]
}
df = pd.DataFrame(data)
print(df)
df.plot(x='Campaign', y='Impressions', kind='bar', color = ['green', 'yellow', 'orange', 'cyan'])
plt.title('Impressions by Campaign')
plt.xlabel('Campaign')
plt.ylabel('Impression')
plt.show()
df['Campaign'].value_counts().plot(kind='pie', autopct='%0.1f%%', title = 'Campaign Distribution')
plt.show()
y = np.array([35, 25, 25, 15])
c = np.array(data['Campaign'])
plt.pie(y, labels = c, startangle = 90)
plt.show() 