'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Line plot
#For Business purposes and share market
#For prediction of stock prices
#For trend analysis
df.plot(x='Date', y='Sales', kind='line')
#Bar Plot
#For comparing frequencies
#Checking the sales, etc
df.plot(x='Date', y='Sales', kind='bar')
#Histogram is used for probabilty distribution
#Eg: Rainfall distribution
#For density distribution
df.plot(x='Date', y='Sales', kind='hist')
#Box Plot
#Gives statistical information
#For Hypothesis
#Eg: Teeth growth with the supplements
#Quartile: 
#Q1 - 25% percentile(ranking)
#Q2 - median - 50% percentile
#Q4 - 75% percentile
#Uses only one parameter
df.plot(x='Date', kind='box')
#Area plot:
#Area is for cumulative or summation 
df.plot(x='Date', kind='area')
#Scatter plot:
#used to check if there is a linear relation
#Eg: In health sector, comparing BMI etc
df.plot(x='Date', kind='Scatter')
#Pie Chart:
df