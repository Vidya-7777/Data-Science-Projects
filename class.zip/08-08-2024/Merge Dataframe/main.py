'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#use idle for better understanding
import pandas as pd
#more fexible as compared to join
df1 = pd.DataFrame({'Key':['K0','K1','K2'], 'Value':['V0','V1','V2']})
df2 = pd.DataFrame({'Key':['K1','K2','K3'], 'Value':['V3','V4','V5']})
#It is like inner join (like intersection)
result1 = pd.merge(df1,df2,on="Key",how="inner") 
print(result1)
#Here in the Keys, K1 and K2 are common, so the corresponding values in df1 and df2 are printed (For inner join)
#outer operation is like union => it considers all the attributes
result2 = pd.merge(df1,df2,on="Key",how="outer") 
print(result2)
result3 = pd.merge(df1,df2,on="Key",how="left") 
print(result3)
result4 = pd.merge(df1,df2,on="Key",how="right") 
print(result4)