'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import pandas as pd
#join is based on the index
df1 = pd.DataFrame({'A':['A0','A1','A2'], 'B':['B0','B1','B2']}, index = ['K0','K1','K2'])
df2 = pd.DataFrame({'C':['C0','C1','C2'], 'D':['D0','D1','D2']}, index = ['K1','K2','K3'])
#Join dataframes based on their indexes
result = df1.join(df2)
print(result)
result2 = df2.join(df1)
print(result2)
df3 = pd.DataFrame({'E':['E0','E1','E2'], 'F':['F0','F1','F2']})
df4 = pd.DataFrame({'G':['G3','G4','G5'], 'H':['H3','H4','H5']})
result3 = df3.join(df4)
print(result3)