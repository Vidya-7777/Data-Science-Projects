'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import pandas as pd
student = pd.DataFrame({'Name':['Tom', 'Lisa', 'Bill', 'Andrew', 'Kiana'], 'Age':[12,13,14,15,16], 'Gender':['Male', 'Female', 'Male', 'Male','Female'], 'Mark':[88,78,65,90,85]})
print(student)
std = pd.DataFrame({'Name':['Emma'], 'Age':[18], 'Gender':['Female'], 'Mark':[87]})
student = student.append(std)
print(student)
student = student.assign(Grade=['A','B','C','A','B','A'])
print(student)
m = student[student['Mark']>80]
print(m)
f = student[(student['Gender'] == 'Female') & (student['Mark']>80)]
print(f)
