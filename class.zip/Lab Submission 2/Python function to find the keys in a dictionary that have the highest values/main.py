'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import numpy as np
dic = {5:"apple", 2:"banana", 8:"jack fruit", 7:"orange", 1:"grapes"}
k = dic.keys()
l = list(k)
arr = np.array(l)
m = np.amax(arr)
print(m)