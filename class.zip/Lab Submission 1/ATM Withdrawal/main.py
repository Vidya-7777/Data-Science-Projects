'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
b = 10000 #Let Raju's balance be 10000 INR
r = int(input("Enter amount to withdraw: "))
if r%5 == 0:
    b = b-r-0.5
    print("Raju's balance after attempting a transaction: ",b,"INR")
else:
    print("Withdrawal amount is not a multiple of 5, hence transaction failed!")
    
