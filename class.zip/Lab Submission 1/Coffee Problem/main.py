'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
n = int(input("Enter the amount Little Kumar has in his pocket: "))
c = int(input("Enter the cost of each coffee cup: "))
m = int(input("Enter number of empty coffee cups to return as per loyalty program: "))
k = int(input("Enter number of free coffee cups to return as per the additional bonus in loyalty program: "))
x = n/c
y = x/m
z = y/k
c = x+y+z
print("Little Kumar enjoys", int(c), "coffee cups in total.")

