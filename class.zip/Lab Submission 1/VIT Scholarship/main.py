'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
g = int(input("Enter 1 if you are first to graduate in your family, else enter 0: "))
m = int(input("Enter your math marks: "))
p = int(input("Enter your physics marks: "))
c = int(input("Enter your chemistry marks: "))
avg = (m+p+c)/3
if g==1 and m>0 and p>0 and c>0:
    if avg>98:
        print("You are eligible for the scholarship!")
    else:
        print("Your average in math, physics and chemistry is less than 98!")
elif g==0 or g!=1:
    print("You are not the first to graduate from your family!")
else:
    print("Marks you entered are invalid!")
    
    
