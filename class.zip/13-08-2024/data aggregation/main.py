'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#involves performing operations on groups of data, such as calculating the sum, mean, count, or the other statistical measures
#data aggregation includes functions like groupby(), agg(), pivot_table()
#groupby():It is used to group the data based on one or more columns and then apply an aggregation function to each group.
import pandas as pd
data = {'Name': ['John', 'Alice', 'Bob', 'Kelly', 'Vito'], 'Age' : [25, 30, 35, 30, 27], 'Dept':['hr', 'sales', 'engg', 'sales', 'engg'], 'Salary':[25000, 60000, 40000, 50000, 55000]}
df = pd.DataFrame(data)
print(df)
#Grouping the data by department and calculating the average salary
a = df.groupby('Dept')['Salary'].mean()
print(a)
#total salary for each department
#or department wise cost to the company
t = df.groupby('Dept')['Salary'].sum()
print(t)
df = df.assign(Design = ['junior', 'asscociate', 'senior', 'asscociate', 'junior'])
print(df)
#calculating the sum of the salary grouping by designation and the age is maximum
result = df.groupby('Design').agg({'Salary':'sum', 'Age':'max'})
print(result)
#pivot_table() : It is used to create a spreadsheet-style pivot table based on the data. It allows you to summarize and aggregate data in a flexible way.
result2 = df.pivot_table(index = 'Name', columns = 'Dept', values = 'Salary')
print(result2)