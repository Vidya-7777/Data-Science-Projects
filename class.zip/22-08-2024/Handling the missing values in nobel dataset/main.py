'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
df = pd.read_csv("nobel.csv")
'''print(df)'''
#Plot a histogram of the year of the Nobel Prize. This shows the distribution of the years in which the prizes were awarded
#to show how many prizes in a particular year
#using value counts
#bin bounderies
'''df['year'].value_counts().plot(kind='hist')
plt.show()'''
#Plot a bar plot of the number of Nobel Prizes per Category. This shows which category have the most prizes.
df['category'].value_counts().plot(kind='bar')
plt.show()
#Plot a pie chart of the number of Nobel Prizes per country. This shows the top 10 countries by number of prizes.
#Should show only the top 10 countries in the pie chart
df['organization_country'].value_counts().head(10).plot(kind='pie', autopct='%0.1f%%', title = 'Nobel Prizes per country')
plt.show()
#How has the number of Nobel Prizes awarded in each category(eb., Chemistry, Peace, Literature) changed over time?
'''chem = df[df['category']=='Chemistry']
df.plot(x = 'chem', kind='line')
plt.show()'''