'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import seaborn as sns
#Simplilearn
#colour pallet 
#High level interface for statistics
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv('mtcars (1).csv')
print(df.head()) #gives top 5 observations
print(df.tail()) #gives bottom 5 observations
print(df.info()) # gives datatypes
print(df.shape) #32 cars and 12 features
#res = sns.barplot(df['cyl'], df['carb'])
#res = sns.barplot(x='cyl', y='carb', data=df, palette=['purple', 'pink', 'violet'])
#res = sns.barplot(x='cyl', y='carb', data=df, color='yellow')
res = sns.barplot(x='cyl', y='carb', data=df, palette='rocket')
plt.show()
res1 = sns.barplot(df['cyl'].value_counts())
plt.show()
#adding legends in barplot in python
res1 = sns.barplot(df['cyl'].value_counts(), palette='Set1', legend='cyl')
plt.show()
sns.countplot(x='gear', hue='cyl', data=df, palette='Set1')
plt.show()
