'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Distribution plot in Seaborn:
#distplot() supports distribution of continuous data
sns.distplot(df.mpg, bins=10, color='g')
plt.show()
sns.displot(df.mpg, bins=10, color='g')
plt.show()
#learn kurthosis and skewness