'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import pandas as pd
import plotly.express as px
import numpy as np
#5 V's of big data
#Volume - the amount of data
#Variety - Diversity of data
#Velocity - Speed of data generation
#Veracity - Accuracy of data
#Value - Worth of data
#Creating a random data
#Set a random seed for reproducibility
np.random.seed(42)
#Create a list of fruits, regions, and generate random sales data
fruits = ['Apple', 'Banana', 'Cherries', 'Dates', 'Elderberries', 'Figs', 'Grapes', 'Honeydew']
regions = ['North', 'South', 'East', 'West']
#Generate the data frame
data = {
    'Fruit' : np.random.choice(fruits, 100), #for integer values
    'Region' : np.random.choice(regions, 100),
    'Quantity' : np.random.randint(1, 50, size=100), #tells number of samples
    'Price' : np.random.uniform(90.5, 255.0, size=100) #for float values
}
df = pd.DataFrame(data)
print(df.head())
print(df.describe())
print(df.info())
#Creating a box plot for price distribution by fruit
fig_box = px.box(df, x='Fruit', y='Price', title='Price Distribution by Fruit')
fig_box.show()
fig_scatter= px.scatter(df, x='Quantity', y='Price', title='Quantity vs Price by Region', trendline = 'ols', color='Region', size='Price', symbol='Fruit')
fig_scatter.show()
#histogram is based on one feature
fig_hist= px.histogram(df, x='Price', nbins=100, title='Price Distribution') #nbins helps in determining class interval
fig_hist.show()
#line charts
fig_line = px.line(df, x='Fruits', y='Price', color='Fruits')
fig_line.show()
#pie chart
fig_pie = px.pie(df, names='Fruits', values='Quantity')
fig_pie.show()
#bubble chart
#Stacking plot or categorical axis
#Check plotly graphs or plots
#bar plot
fig_bar = px.bar(df, x='Fruits', y='Regions', labels={'Regions':'Regions distributed', 'Fruits': 'Various Fruits'}, color='Fruits')
fig_bar.show()
#open government data
#data.gov.in