'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import pandas as pd
data = {
    'Employee ID': [1,2,3,4,5],
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva'],
    'Salary': [45000, 54000, 58000, 63000, 72000]
}
df = pd.DataFrame(data)
print(df)
#Display the first 5 rows
print(df.head())
#Display the last 5 rows
print(df.tail())
#Display basic statistics of the DataFrame
print(df.describe())
#Display the DataFrame info
print(df.info())