'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import numpy as np
A = np.array([[1,2], [3,4]])
B = np.array([[5,6], [7,8]])
#Matrix Multiplication
product = np.dot(A,B)
print(product) 
#Determinant
det = np.linalg.det(A)
print(det)
#Inverse
inv = np.linalg.inv(A)
print(inv)