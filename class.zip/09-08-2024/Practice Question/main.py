'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import pandas as pd
#student = pd.DataFrame(columns=['Name', 'Age', 'Gender', 'Mark'])
std = pd.DataFrame({'Name':['Tom', 'Lisa', 'Bill', 'Andrew'], 'Age':[12,13,14,15], 'Gender':['Male', 'Female', 'Male', 'Male'], 'Mark':[85,78,65,90]})
print(std)
stda = pd.DataFrame({'Name':['Emma'], 'Age':[17], 'Gender':['Female'], 'Mark':[99]})
stdap = std.append(stda)
print(stdap)
stdg = stdap.assign(Grade=['B','C','D','A','A'])
print(stdg)
m = stdg[stdg['Mark']>80]
print(m)
f = stdg[stdg['Gender'] == 'Female']
print(f)
fm = stdg[(stdg['Gender'] == 'Female') & (stdg['Mark']>80)]
print(fm)
fmo = stdg[(stdg['Gender'] == 'Female') | (stdg['Mark']>80)]
print(fmo)