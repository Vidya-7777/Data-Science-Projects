'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#Write a python 
num = [1, 2, 3, 6, 7, 9]
l = len(num)
m = num[0]
for i in range(l-1):
    if m < num[i]:
        m = num[i]
for i in range(l-1):
    if num[i] == m:
        num.remove(num[i])
m1 = num[0]
for i in range(l-2):
    if m1 < num[i]:
        m1 = num[i]
print(m1)
#finding the largest element in a dictionary and printing it n times if it occurs n times
