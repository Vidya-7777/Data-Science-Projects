'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
num = [1, 2, 4, 6, 7, 5, 7, 8, 9]
l = len(num)
for i in range(l-1):
    for j in range(i+1, l-1):
        if num[i] == num[j]:
            num.remove(num[j])
print(num)