'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#difference between sort and sorted
#Lists are 1-D
fruits = ["pineapple", "banana", "cherry"]
print(fruits[1])
print(fruits)
fruits.append("orange")
print(fruits)
fruits.remove("banana")
print(fruits)
fruits.pop()
fruits.insert(2, "mango")
fruits.sort()
print(fruits)