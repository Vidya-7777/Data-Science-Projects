'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import numpy as np
arr = np.array([[1,2,3], [4,5,6]])
#Sum of all elements
total_sum = np.sum(arr)
print(total_sum)
#Sum along axis 0 (columns)
col_sum = np.sum(arr, axis=0)
print(col_sum)
#Sum along axis 1 (rows)
row_sum = np.sum(arr, axis=1)
print(row_sum)
#also finding the mean