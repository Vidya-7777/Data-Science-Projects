'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
import numpy as np
#Reshaping allows us to change the shape of an array without changing its data
arr= np.array([[1,2,3], [4,5,6]])
reshaped_array = arr.reshape((3,2))
print(reshaped_array)
#reshaping cannot be done in any shape (it can only be done based on the size of the array) eg: here it can't be reshaped to 3x3
flattened_array = arr.flatten()
print(flattened_array)