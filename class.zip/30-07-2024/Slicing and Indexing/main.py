'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
#pat question especially boolean indexing
import numpy as np
arr = np.array([1,2,3,4,5])
#accesing the element:
element = arr[0] 
print(element)
#Slicing the element:
slice_arr = arr[1:4]
print(slice_arr)
#Boolean indexing:
bool_index = arr[arr > 3] 
#here elements are printed by checking the condition, that is array elements greater than 3 are printed, that is 4 and 5
print(bool_index)
#here we can have a combination of logical expressions like !
bool_index_2 = arr[arr != 3]
print(bool_index_2)
bool_index_3 = arr[(arr<5) & (arr>2)] #here "and" is "&"
print(bool_index_3)
bool_index_4 = arr[(arr<5) | (arr>2)]
print(bool_index_4)