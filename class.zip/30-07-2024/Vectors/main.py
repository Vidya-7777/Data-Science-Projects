'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
''' things to learn:
1. np.arrange
2. creating a list and multiplying it to show replications.
3. step value in numpy arrays
3. aggregation function for the input arrays
'''
'''import numpy as np
list1 = [10,20,30,40,50]   
list2 = [45,54,98,87,78]  
   
#vtr1 = np.array(list1)   
#print(vtr1)   
vtr1 = np.array(list1+list2)   
print(vtr1)  
'''
'''
a)Create and store a vector that contains the following, in the order:
- A sequence of length 5 from 3 to 6(inclusive)
- A twofold repition of the vector c(2, -5.1, -33)
- the value (7/42 + 2)
b)Extract the first and the last elementof your vector from a), storing them as a new object.
'''
'''import numpy as np
list1 = [10,20,30,40,50]   
list2 = [45,54,98,87,78]  
   
#vtr1 = np.array(list1)   
#print(vtr1)   
vtr1 = np.array(list1+list2)   
print(vtr1)  
'''
import numpy as np

















