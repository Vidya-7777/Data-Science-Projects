'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class box:
    def __init__(self, length, width, depth):
        self.length = length
        self.width = width
        self.depth = depth
    def volume(self, length, width, depth):
        #return ({self.length} * {self.width} * {self.depth}) => should not be used while using "return"
        #alternate method:
        #vol = self.length * self.width * self.depth
        #return vol
        return length * width * depth
l = int(input("Enter length: "))
w = int(input("Enter width: "))
d = int(input("Enter depth: "))
v = box(l, w, d)
print(v.volume(l, w, d))