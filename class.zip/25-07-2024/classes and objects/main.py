'''

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

'''
class Dog:
    species = "Canis familiaris" #Common to the whole class
    def __init__(self, name, age):
        #Initializer/Instance attributes(this is similar to constructor in Java)
        self.name = name
        self.age = age
    #creation of instance methods
    def description(self):
        return f"{self.name} is {self.age} years old"
    def speak(self, sound):
        return f"{self.name} says {sound}"
    #create an instance of the dog class
my_dog = Dog("Taco", 5)
print(my_dog.description())
print(my_dog.name)
print(my_dog.age)
print(my_dog.speak("bow bow"))    
    