# 
# Welcome to GDB Online.
# GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
# C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
# Code, Compile, Run and Debug online from anywhere in world.
# 
# 

#Dimensionality reduction
#simplifies the dataset by reducing number of features
#mitigate overfitting, reduce computational costs, and better visualize the data
#methods of dimensionality reduction
#1. Principal Component Analysis(PCA)
#It is a technique that reduces the dimensionality of data by transforming the original variables into new, uncorreelated
#variables called principal components. These components are ordered so that the first few retain most of the variation 
#present in the original dataset.
library(ggplot2)
library(caret)
data(iris)
head(iris)

pca_model <- prcomp(iris[, 1:4], centre = TRUE, scale. = TRUE)
summary(pca_model)
#adding all the proption variance should be 1
PC1 <- iris$Sepal.Length
PC2 <- iris$Sepal.Width
pca_df <- as.data.frame(pca_model$x)
pca_df$Species <- iris$Species
ggplot(pca_df, aes(PC1, PC2, color = Species))+
  geom_point(size=1)+
  ggtitle("PCAjsfj")+
  theme_minimal()

p1 <- ggplot(iris, aes(Sepal.Length, Sepal.Width, color=Species))+geom_point()
#ggplot(dataset, aes(x, y, color=)) + geom_point()
p1

#linear discriminat analysis 
library(MASS)
#StarQuest with josh stromer LDA - youtube channel
#lda(y~., data=)
#. => all other values
#Fitting the LDA model
lda_model <- lda(Species~., data = iris)
lda_model
#Sum of LD1 and LD2 is 1, where LD1 comes around 99%
#Projecting the data onto LDA components
LD1 <- iris$Sepal.Length
LD2 <- iris$Sepal.Width
lda_pred <- predict(lda_model)
lda_df <- data.frame(lda_pred$x)
lda_df$Species <- iris$Species
#Plotting LDA
ggplot(lda_df, aes(LD1, LD2, color=Species))+
  geom_point(size = 2)+
  ggtitle("LDA on Iris Dataset")+
  theme_minimal()

#Recursive Feature Elimination(RFE):
#recursively fits a model and removes the least important features.
#like jenga game
#using the mtcars dataset to predict mpg(miles per gallon) using RFE for feature selection
data(mtcars)
#Setting up control for RFE
control <- rfeControl(functions = lmFuncs, method = "cv", number = 10)
#cv => cross validation
#number = 10(folds) => standard
#Applying RFE
rfe_model <- rfe(mtcars[,-1], mtcars$mpg, sizes = c(1:7), rfeControl = control)
#Summary of the RFE model
rfe_model
#Plotting the results of RFE
plot(rfe_model, type = c("g", "o"))
